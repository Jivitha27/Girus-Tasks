# Sudoku Validator with Custom Python Logic

This project provides a Python-based Sudoku validator that checks if a given 9x9 Sudoku board is valid according to standard Sudoku rules. The validator ensures that each row, column, and 3x3 sub-box contains unique digits from 1 to 9, ignoring empty cells.

## Features

- Validates completeness and correctness by checking rows, columns, and boxes.
- Skips empty cells represented by '.'.
- Uses efficient sets-based logic to track seen numbers in a single pass.
- Simple API function: `validate_sudoku_board(board)` that returns `True` or `False`.
- Comes with a sample Sudoku board test.

## Installation

No dependencies are required beyond Python 3.6 or newer.

## Usage

1. Place your Sudoku board as a 9x9 list of lists, with each cell as a string digit `"1"`–`"9"` or `"."` for empty.

2. Call the function `validate_sudoku_board(board)`.

```python
from sudoku_validator_alternative import validate_sudoku_board

board = [
    ["5","3",".",".","7",".",".",".","."],
    ["6",".",".","1","9","5",".",".","."],
    [".","9","8",".",".",".",".","6","."],
    ["8",".",".",".","6",".",".",".","3"],
    ["4",".",".","8",".","3",".",".","1"],
    ["7",".",".",".","2",".",".",".","6"],
    [".","6",".",".",".",".","2","8","."],
    [".",".",".","4","1","9",".",".","5"],
    [".",".",".",".","8",".",".","7","9"]
]

print("Is the Sudoku valid?", validate_sudoku_board(board))