def validate_sudoku_board(board):
    """
    Validate a 9x9 Sudoku board.
    The board is valid if:
      - Each row contains no duplicate digits 1-9.
      - Each column contains no duplicate digits 1-9.
      - Each 3x3 box contains no duplicate digits 1-9.
    Empty cells are represented by '.' and ignored.
    """
    # Prepare sets to track seen digits for rows, columns, and boxes
    seen_in_rows = [set() for _ in range(9)]
    seen_in_cols = [set() for _ in range(9)]
    seen_in_boxes = [set() for _ in range(9)]

    for row_idx in range(9):
        for col_idx in range(9):
            val = board[row_idx][col_idx]
            if val == '.':
                continue  # Skip empty cells

            # Calculate box index based on row and column
            box_idx = (row_idx // 3) * 3 + (col_idx // 3)

            # Check if val already seen in row, col or box
            if (val in seen_in_rows[row_idx] or
                val in seen_in_cols[col_idx] or
                val in seen_in_boxes[box_idx]):
                return False

            # Add val to seen sets
            seen_in_rows[row_idx].add(val)
            seen_in_cols[col_idx].add(val)
            seen_in_boxes[box_idx].add(val)

    return True


if __name__ == "__main__":
    sudoku_board = [
        ["5","3",".",".","7",".",".",".","."],
        ["6",".",".","1","9","5",".",".","."],
        [".","9","8",".",".",".",".","6","."],
        ["8",".",".",".","6",".",".",".","3"],
        ["4",".",".","8",".","3",".",".","1"],
        ["7",".",".",".","2",".",".",".","6"],
        [".","6",".",".",".",".","2","8","."],
        [".",".",".","4","1","9",".",".","5"],
        [".",".",".",".","8",".",".","7","9"]
    ]

    is_valid = validate_sudoku_board(sudoku_board)
    print("Is the Sudoku valid?", is_valid)

