# Knights and Portals

This project provides a Python solution to the "Knights and Portals" problem, which determines the minimum number of steps a knight can take to reach a portal on a given board. The knight moves in an L-shape, and the board may contain obstacles.

## Features

- Calculates the minimum steps required for a knight to reach a portal.
- Handles obstacles represented by `'#'` that the knight cannot pass through.
- Simple API function: `min_steps_to_portal(board)` that returns the minimum steps or `-1` if the portal is unreachable.

## Installation

No external dependencies are required beyond Python 3.6 or newer.

## Usage

1. Define a 2D list representing the board, where:
   - `'K'` represents the knight's starting position.
   - `'P'` represents the portal's position.
   - `'#'` represents obstacles.
   - `'.'` represents empty spaces.

2. Call the function `min_steps_to_portal(board)` with the board as an argument.

```python
from knights_and_portals import min_steps_to_portal

board = [
    ['K', '.', '.', '#', '.', '.', '.'],
    ['.', '#', '.', '.', '.', '#', '.'],
    ['.', '#', '.', '.', '.', '.', '.'],
    ['.', '.', '#', '#', '.', '.', '.'],
    ['#', '.', '#', 'P', '.', '#', '.']
]

print("Minimum steps to reach portal:", min_steps_to_portal(board))