from collections import defaultdict

def alien_order(words):
    # Build graph - adjacency list representation
    graph = defaultdict(set)
    nodes = set(char for word in words for char in word)

    # Build edges from given word list
    for i in range(len(words) - 1):
        first, second = words[i], words[i + 1]
        min_length = min(len(first), len(second))
        for j in range(min_length):
            if first[j] != second[j]:
                graph[first[j]].add(second[j])
                break
        else:
            # check invalid case like ["abc", "ab"] where prefix order is violated
            if len(first) > len(second):
                return ""

    visited = {}  # char -> True if visiting, False if visited
    result = []

    def dfs(char):
        if char in visited:
            return visited[char]  # if True, cycle detected; if False, already visited

        visited[char] = True  # mark as visiting
        for neighbor in graph[char]:
            if dfs(neighbor):
                return True   # cycle detected
        visited[char] = False  # mark as visited
        result.append(char)  # append after visiting all neighbors (postorder)
        return False

    for node in nodes:
        if node not in visited:
            if dfs(node):
                return ""  # cycle detected, invalid order

    return "".join(result[::-1])  # reverse to get correct topological ordering


if __name__ == "__main__":
    words = ["wrt", "wrf", "er", "ett", "rftt"]
    print("Alien Dictionary Order:", alien_order(words))
