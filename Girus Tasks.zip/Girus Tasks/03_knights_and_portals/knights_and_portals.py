from collections import deque

def min_steps_to_portal(board):
    rows, cols = len(board), len(board[0])
    directions = [(-2, -1), (-1, -2), (1, -2), (2, -1), (2, 1), (1, 2), (-1, 2), (-2, 1)]

    # Locate the knight's starting position and the portal's position
    start = None
    portal = None

    for r in range(rows):
        for c in range(cols):
            if board[r][c] == 'K':
                start = (r, c)
            elif board[r][c] == 'P':
                portal = (r, c)

    # BFS initialization
    queue = deque([start])
    visited = set([start])
    steps = 0

    while queue:
        for _ in range(len(queue)):
            x, y = queue.popleft()
            if (x, y) == portal:
                return steps

            # Explore all possible knight moves
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if 0 <= nx < rows and 0 <= ny < cols and board[nx][ny] != '#' and (nx, ny) not in visited:
                    visited.add((nx, ny))
                    queue.append((nx, ny))

        steps += 1  # Increment steps after exploring all positions at the current level

    return -1  # Return -1 if the portal is unreachable

if __name__ == "__main__":
    board = [
        ['K', '.', '.', '#', '.', '.', '.'],
        ['.', '#', '.', '.', '.', '#', '.'],
        ['.', '#', '.', '.', '.', '.', '.'],
        ['.', '.', '#', '#', '.', '.', '.'],
        ['#', '.', '#', 'P', '.', '#', '.']
    ]
    print("Minimum steps to reach portal:", min_steps_to_portal(board))
