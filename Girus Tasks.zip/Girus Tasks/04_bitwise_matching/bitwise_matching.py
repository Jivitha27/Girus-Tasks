def bitwise_match_count(a: int, b: int) -> int:
    # XOR of a and b gives bits that are different
    xor = a ^ b
    count = 0
    # Count number of bits that are zero in xor (matching bits)
    for i in range(32):
        if (xor & (1 << i)) == 0:
            count += 1
    return count

if __name__ == "__main__":
    a, b = 29, 21
    print("Matching bit positions between", a, "and", b, ":", bitwise_match_count(a, b))
