# Matrix Islands with Diagonals

This project provides a Python solution for counting the number of islands in a binary matrix, where islands are groups of adjacent 1s connected vertically, horizontally, **and diagonally**. The core algorithm uses an iterative depth-first search (DFS) approach to explore connected land cells.

## Features

- Counts islands considering diagonal connections alongside vertical and horizontal adjacency.
- Uses an iterative DFS with a stack for robust and clear traversal.
- Marks visited cells to avoid repeated processing.
- Simple API function: `count_islands(matrix)` that returns the total number of islands.

## Installation

No external dependencies required beyond Python 3.6 or newer.

## Usage

1. Define a 2D list representing the matrix, where:
   - `1` represents land.
   - `0` represents water.

2. Call the function `count_islands(matrix)` with the matrix as input.

```python
from matrix_islands import count_islands

mat = [
    [1, 1, 0, 0],
    [0, 1, 0, 0],
    [1, 0, 0, 1],
    [0, 0, 1, 1]
]

print("Number of islands including diagonals:", count_islands(mat))