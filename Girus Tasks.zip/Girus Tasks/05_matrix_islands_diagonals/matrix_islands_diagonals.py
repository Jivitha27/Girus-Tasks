def count_islands(matrix):
    if not matrix:
        return 0

    rows, cols = len(matrix), len(matrix[0])
    visited = [[False] * cols for _ in range(rows)]
    directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

    def iterative_dfs(r, c):
        stack = [(r, c)]
        visited[r][c] = True
        
        while stack:
            cr, cc = stack.pop()
            for dr, dc in directions:
                nr, nc = cr + dr, cc + dc
                if 0 <= nr < rows and 0 <= nc < cols and matrix[nr][nc] == 1 and not visited[nr][nc]:
                    visited[nr][nc] = True
                    stack.append((nr, nc))

    count = 0
    for r in range(rows):
        for c in range(cols):
            if matrix[r][c] == 1 and not visited[r][c]:
                iterative_dfs(r, c)
                count += 1

    return count

if __name__ == "__main__":
    mat = [
        [1, 1, 0, 0],
        [0, 1, 0, 0],
        [1, 0, 0, 1],
        [0, 0, 1, 1]
    ]
    print("Number of islands including diagonals:", count_islands(mat))
